export const environment = {
  production: true,
  apiUrl: 'http://localhost:8180/api',
  tokenName :  "authToken",
  origin:'http://localhost:4200' 
};