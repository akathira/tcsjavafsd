export const environment = {
    production: false,
    apiUrl: 'http://localhost:8180/api',
    tokenName :  "authToken",
    origin:'http://localhost:4200' 
  };